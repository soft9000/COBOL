#include <errno.h>

int get_errno() {
    return errno;
}

